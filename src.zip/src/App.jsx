import React, { useEffect, useState } from 'react'
import { IoSunnyOutline } from "react-icons/io5";
import { LuSunrise } from "react-icons/lu";
import { LuSunset } from "react-icons/lu";
import { CiCloud } from "react-icons/ci";
import { WiHumidity } from "react-icons/wi";
import { IoSpeedometerOutline } from "react-icons/io5";
import { FaWind } from "react-icons/fa";
import SearchBarWithTheme from './components/SearchBarWithTheme';
import TimeClock from './components/TimeClock';
import WeatherDetails from './components/WeatherDetails';

function App() {

  const [city, setCity] = useState("");
  const [isDarkMode, setDarkMode] = useState(false);



  return (
    <div className={` ${isDarkMode ? "bg-[url(./dark.png)] text-white " : 'bg-[url(./light.png)]'}  bg-cover h-screen p-8 flex flex-col justify-center items-center gap-8 `} >

      <SearchBarWithTheme
        city={city} setCity={setCity}
        isDarkMode={isDarkMode}
        setDarkMode={setDarkMode}
      />


      {/* clock weather and details section start here */}
      <section className='grid gap-4 grid-cols-[1fr_3fr] w-full'>
        <TimeClock />


        {/* weather details --> right part  */}

        <WeatherDetails city={city} />
      </section>
      {/* clock weather and details section End here */}
    </div>
  )
}

export default App