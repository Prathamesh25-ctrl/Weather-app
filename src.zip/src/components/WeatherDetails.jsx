import React, { useEffect, useState } from 'react'
import { FaWind } from 'react-icons/fa';
import { IoSpeedometerOutline } from 'react-icons/io5';
import { LuSunrise, LuSunset } from 'react-icons/lu';
import { WiHumidity } from 'react-icons/wi';
import Loader from "./ui/Loader";

function WeatherDetails({city}) {

    const [weatherData, setWeatherData] = useState(null);
    const [error, setError] = useState(null);
    const [isLoading, setLoading] = useState(true);



    const handleFetch = async (cityName = "mumbai") => {

        let city =  cityName.length <=0 ? "mumbai" : cityName;
        try {
            setLoading(true);
            const WEATHER_API = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=542ad7bb730bf3ef57fa1cd40847dbf7&units=metric`
            const response = await fetch(WEATHER_API);
            const data = await response.json();

            if (data.cod === '404') {
                setError(data.message);
                setLoading(false);
                return
            }

            setError(null);
            setWeatherData(data);
            setLoading(false);


        } catch (error) {
            console.log("error" , error);
            setError(error.message);
            
        }
        finally {
            setLoading(false);
        }
    }

    console.log("cityName", city);
    
    useEffect(() => {
        handleFetch(city);
    }, [city]);


    if (isLoading)  {
        return <h1><Loader /></h1>;
    }
    if (error) {
        return <h1>{error}..</h1>
    }



    const { main, sys, name, weather } = weatherData;
    const { temp, feels_like, pressure, humidity } = main;
    const { sunrise, sunset } = sys;
    const { icon, main: WeatherTitle, description } = weather[0];




    const local_sunrise = new Date(sunrise * 1000)
        .toLocaleTimeString("en-IN", {
            minute: "2-digit",
            hour: "2-digit",
        }).toUpperCase();

    const local_sunset = new Date(sunset * 1000)
        .toLocaleTimeString("en-IN", {
            minute: "2-digit",
            hour: "2-digit",
        }).toUpperCase();
    return (
        <>
            <div className='w-full grid grid-cols-3   items-center border-y-sky-500 font-bold'>
                {/* first column --> temprature sunrise, and sunset */}
                <div className='space-y-2 '>
                    {/* first row --> temprature */}
                    <div>
                        <h2 className='font-bold text-4xl '>{Math.round(temp)}°C</h2>
                        <p className=''> Feels Like : <span>{Math.round(feels_like)}°C</span>
                        </p>
                    </div>
                    {/* second row --> sunrise */}
                    <div className='flex items-center gap-2'>
                        {/* left icon --> icon */}
                        <div>
                            <LuSunrise className='text-4xl ' />
                        </div>
                        {/* right part title and timing  */}
                        <div>
                            <h3 className='font-bold -mb-1.5 '>Sunrise</h3>
                            <span className=''>{local_sunrise}</span>
                        </div>
                    </div>
                    {/* third row --> sunset */}
                    <div className='flex items-center gap-2 '>
                        {/* left icon --> icon */}
                        <div>
                            <LuSunset className='text-4xl' />
                        </div>
                        {/* right part title and timing  */}
                        <div>
                            <h3 className='font-bold -mb-1.5'>Sunset</h3>
                            <span>{local_sunset}</span>
                        </div>
                    </div>
                </div>

                {/* Second column --> city name weather icon , and weather status */}
                <div className=' space-x-1 space-y-2 '>
                    {/* city row 1 */}
                    <div>
                        <h1 className='font-medium text-2xl'>{name}</h1>
                    </div>
                    {/* icon */}
                    <div>
                        <img src={`https://openweathermap.org/payload/api/media/file/${icon}.png`} alt={`description`} />
                    </div>
                    {/* weather status */}
                    <div>
                        <h2 className='font-bold'>{WeatherTitle}</h2>
                        <p className='font-bold'> {description} </p>
                    </div>
                </div>
                {/* Third column --> humidity pressure and windspeed */}
                <div className=' space-y-4'>
                    {/* humidity start */}
                    <div className='flex gap-5'>
                        <div>
                            < WiHumidity className='text-5xl' />
                        </div>
                        <div>
                            <h2>{humidity}%</h2>
                            <h3>Humidity</h3>
                        </div>
                    </div>
                    {/* humidity end here */}
                    {/* Pressure start here */}
                    <div className='flex gap-5'>
                        <div>
                            < IoSpeedometerOutline className='text-5xl' />
                        </div>
                        <div>
                            <h2>{pressure}</h2>
                            <h3>Pressure</h3>
                        </div>
                    </div>
                    {/* Pressure start here */}
                    {/* windspeed start here */}
                    <div className='flex gap-5'>
                        <div>
                            <FaWind className='text-5xl' />
                        </div>
                        <div>
                            <h2>{weatherData.wind.speed}</h2>
                            <h3>Wind Speed</h3>
                        </div>
                    </div>
                    {/* windspeed End here */}
                </div>
            </div>
        </>
    )
}

export default WeatherDetails