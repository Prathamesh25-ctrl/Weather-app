import React, { useRef, useState } from 'react'
import { IoSunnyOutline } from 'react-icons/io5';
import { LuSunMoon } from 'react-icons/lu';

function SearchBarWithTheme({ city, setCity , isDarkMode, setDarkMode }) {
    const searchInput = useRef(null);

    const handleSearch = (e) => {
        e.preventDefault();
        setCity(searchInput.current.value);
    };

    return (
        <>
            {/* Search bar and tooogle button Start here */}
            <div className='flex gap-4 w-[40%]'>
                {/* search bar */}
                <form className='grow w-full flex' onSubmit={handleSearch}>

                    <input type="text"
                        placeholder="Enter Your City (Ex.mumbai)"
                        //value={city}
                        required
                        ref={searchInput}
                        className='w-full rounded-l-lg py-2 px-1 bg-amber-50 placeholder:text-gray-500 placeholder:italic outline-none shadow-xl/30' />

                    <button type='submit' className='bg-black text-amber-50 rounded-r-lg py-1.5 px-2 shadow-xl/30 cursor-pointer'>Search</button>

                </form>
                <button onClick={()=>{
                    setDarkMode(!isDarkMode)
                }}>
                {isDarkMode ? (
                <LuSunMoon className="text-3xl " />
                ):(
                    <IoSunnyOutline className="text-3xl" />
                )} 
                </button>

            </div>
            {/* Search bar and tooogle button End here */}
        </>
    )
}

export default SearchBarWithTheme