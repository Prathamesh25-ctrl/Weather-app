import React, { useEffect, useState } from 'react'

function TimeClock() {

    const [timer, setTimer] = useState(new Date().toLocaleTimeString());
    const [date, setDate] = useState(new Date().toDateString());



    useEffect(() => {
        const timerId = setInterval(() => {
            const date = new Date().toLocaleTimeString();
            setTimer(date);
        }, 1000);

        

        //   clean up function
        return () => {
            clearInterval(timerId);
        };
    }, []);

    return (
        <>
            {/* clock timer --> left part */}
            <div className=' w-full  space-y-8  '>
                <h1 className='text-3xl items-center font-bold'>
                    Clock
                </h1>
                <h2 className='text-2xl'>
                    {timer}
                </h2>
                <h3 className='text-xl'>
                    
                </h3>
            </div>
            {/* clock timer end here */}
        </>
    )
}

export default TimeClock