import React from 'react'

function Loader() {
  return (
    <div className="  w-[80%] grid grid-cols-3 items-center gap-5  rounded-xl shadow-md py-6 px-4">
      {/* //* first column ->  temperature  , sunrise , and sunset */}
      <div className=" space-y-4">
        {/* first row -> temperature */}
        <div className="h-16 bg-slate-400 rounded animate-pulse"> </div>
        <div className="h-6 bg-slate-400 rounded animate-pulse"> </div>
        {/* second row -> sunrise */}
        <div className="h-14 bg-slate-400 rounded animate-pulse"></div>
        {/* third row -> sunset */}
        <div className="h-14 bg-slate-400 rounded animate-pulse"></div>
      </div>
      {/* //*second column ->  city name  , weather icon , weather status */}
      <div className="text-center space-y-4">
        <h3 className="h-12 bg-slate-400 rounded animate-pulse"></h3>
        {/* image icon */}
        <div className=" h-24 bg-slate-400 rounded animate-pulse"></div>
        <div className="flex flex-col gap-3">
          <div className="h-12 bg-slate-400 rounded animate-pulse"> </div>
          <div className="h-4 bg-slate-400 rounded animate-pulse"> </div>
        </div>
      </div>

      {/* //* third column ->  humidity  , pressure , and windspeed */}
      <div className="space-y-6">
        {/* humidity */}
        <div className="flex gap-3 items-stretch">
          <div className=" w-14 h-14 bg-slate-400 rounded animate-pulse"> </div>
          <div className="grow h-14 bg-slate-400 rounded animate-pulse"> </div>
        </div>
        {/* pressure */}
        <div className="flex gap-3 items-center">
          <div className=" w-14 h-14 bg-slate-400 rounded animate-pulse"> </div>
          <div className="grow h-14 bg-slate-400 rounded animate-pulse"> </div>
        </div>
        {/* windspeed */}
        <div className="flex gap-3 items-center">
          <div className=" w-14 h-14 bg-slate-400 rounded animate-pulse"> </div>
          <div className="grow h-14 bg-slate-400 rounded animate-pulse"> </div>
        </div>
      </div>
    </div>
  )
}

export default Loader